import React from 'react';
import { Profile } from '../../modules';

const UserPage = () => {
  return <Profile />;
};

export default UserPage;
