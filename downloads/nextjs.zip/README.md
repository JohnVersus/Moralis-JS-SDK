# Demo NextJS Wagmi Auth

## Run locally

1. Copy `.env.local.example` to `.env.local` and fill in the values
2. Install all dependencies `yarn` or `npm install`
3. Run `yarn dev` to start the Next.js application
